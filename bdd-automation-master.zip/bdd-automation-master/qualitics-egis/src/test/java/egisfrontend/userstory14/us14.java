package egisfrontend.userstory14;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class us14 {
	@Given("Consular is searching for Person")
	public void consular_is_searching_for_Person() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Given("<First> and <Names> are entered in First and Names search fields")
	public void first_and_Names_are_entered_in_First_and_Names_search_fields() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Given("CDD check box is checked")
	public void cdd_check_box_is_checked() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Given("clicks on request")
	public void clicks_on_request() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("the visa history records are displayed in the results table")
	public void the_visa_history_records_are_displayed_in_the_results_table() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("<DOB> is entered in DOB search field")
	public void dob_is_entered_in_DOB_search_field() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("an invalid <ANumber> is entered in ANumber search field")
	public void an_invalid_ANumber_is_entered_in_ANumber_search_field() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("the request button is disabled")
	public void the_request_button_is_disabled() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("error message is displayed to the user")
	public void error_message_is_displayed_to_the_user() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("an invalid <First> and <Names> are entered in First and Names search fields")
	public void an_invalid_First_and_Names_are_entered_in_First_and_Names_search_fields() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("an invalid <DOB> is entered in DOB search field")
	public void an_invalid_DOB_is_entered_in_DOB_search_field() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("the request button is disables")
	public void the_request_button_is_disables() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("the CDD box is NOT checked")
	public void the_CDD_box_is_NOT_checked() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("No visa history information should be provided")
	public void no_visa_history_information_should_be_provided() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("the NO box is NOT checked")
	public void the_NO_box_is_NOT_checked() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("the request button should be disable")
	public void the_request_button_should_be_disable() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}
}
